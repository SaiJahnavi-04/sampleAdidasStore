package mobileTest;

import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.*;
import io.appium.java_client.AppiumBy;

public class SampleAdidasStoreTestInMobile extends BrowserTestBase {
	@Test
	public void mobileWidgetTest() throws InterruptedException, IOException {
		driver.get("https://08d282-f8.myshopify.com");
		Thread.sleep(5000);
		driver.findElement(AppiumBy.cssSelector("div[class='modal__toggle-open password-link link underlined-link']")).click();
		driver.findElement(By.id("Password")).sendKeys("ss",Keys.ENTER);
		Thread.sleep(3000);
		List<WebElement> listofProducts = driver.findElements(By.cssSelector("h3[class='card__heading h5']"));
		captureScreenshot("mobileWidgetTest");
		int count = listofProducts.size();
		for(int i=1;i<=count;i++) {
			String products =driver.findElement(By.xpath("(//h3[@class='card__heading h5'])["+i+"]")).getText();
			System.out.println("product["+i+"] : " +products);
		}
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//h3[@class='card__heading h5'])[1]")).click();
		boolean checkproduct = driver.findElement(By.cssSelector("div[class='product__title']")).isDisplayed();
		Assert.assertTrue(checkproduct);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,1000)",""); //Scroll
		Thread.sleep(2000);
		String pumper = driver.findElement(By.cssSelector("a[class='prvw__branding_link']")).getText();
		captureScreenshot("mobileWidgetTest");
		System.out.println(pumper);
		if(pumper.equalsIgnoreCase("powered By pumper")) {
			System.out.println("Yes Pumper Widget is Present");
		}
		else {
			System.out.println("No..! not present");
		}
	}
}
