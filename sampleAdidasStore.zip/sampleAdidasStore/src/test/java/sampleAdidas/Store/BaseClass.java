package sampleAdidas.Store;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.*;

public class BaseClass {
	
	public WebDriver driver;
	
	@Parameters({"Browser","Url"})
	@BeforeClass
	public void setUp(String Browser, String Url) {
		if(Browser.equalsIgnoreCase("Chrome")) {
			driver = new ChromeDriver();
		}
		else if (Browser.equalsIgnoreCase("Edge")) {
			driver = new EdgeDriver();
		}
		else if (Browser.equalsIgnoreCase("Firefox")) {
			driver = new FirefoxDriver();
		}
		else {
			driver = new SafariDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get(Url);
	}
	
	@AfterClass
	public void teardown() {
		driver.quit();
	}
	
	public void captureScreenshot(String tName) throws IOException {
		TakesScreenshot takesScreenshot =(TakesScreenshot) driver;
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
		File destFile = new File(System.getProperty("user.dir")+"/screenshots/"+tName+".png");
		FileUtils.copyFile(sourceFile, destFile);
		System.out.println("Screenshot saved Successfully.");
	}
}
